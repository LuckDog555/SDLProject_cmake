#include <SDL.h>

int main(int argc, char **argv)
{
	SDL_Window* win = nullptr;
	SDL_Renderer* ren = nullptr;
	bool running = true;

	win = SDL_CreateWindow("title", 0, 0, 640, 480, SDL_WINDOW_SHOWN);
	ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED);

	SDL_SetRenderDrawColor(ren,255,0,0,255);
	SDL_Event event = {};

	while (running)
	{
		SDL_RenderClear(ren);
		
		SDL_RenderPresent(ren);
		SDL_Delay(50);
		
		while (SDL_PollEvent(&event))
		{
			switch (event.type)
			{
				case SDL_QUIT:running = false; break;
			}
		}
	}
	
	SDL_DestroyRenderer(ren);
	SDL_DestroyWindow(win);

	return 0;
}
